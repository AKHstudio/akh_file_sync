export default {
    syncTargetDir: process.cwd() + '/akhsync_sync_target',
    worldDirName: 'world',
};
